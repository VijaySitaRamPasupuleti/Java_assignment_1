import java.util.HashMap;
import java.util.Map.Entry;

class Main
{
	String Name;
	int year;
	String Address;
	
	Main(String Name, int year, String Address)
	{
		this.Name=Name;
		this.year=year;
		this.Address=Address;
	}
	public String toString()
	{
		return("\n\t"+Name+"\t"+year+"\t"+Address);
	}
	public static void main(String[] args) 
	{
		Main s1 = new Main("Sandeep",1998, "Bangalore");
		Main s2 = new Main("Sagar",2003, "Mumbai");
		Main s3 = new Main("Rohith",2020, "Hyderabad");
		HashMap<Integer, Main> map = new HashMap<>();
		map.put(1,s1);
		map.put(2,s2);
		map.put(3,s3);
		System.out.println("\tName\tYear\tAddress");
		for(Entry<Integer, Main> m:map.entrySet()) 
		{
			System.out.println(m.getValue());
		}
	}
}
        