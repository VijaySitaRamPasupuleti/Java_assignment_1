public class Circle 
{
	private double radius=1.0;
	private String color="red";
	Circle()	
	{
	
	}
	
	Circle(double r)
	{
	    this.radius = r;
		
	}
	
	double getRadius() {
		return radius;
	}
	
	double getArea() 
	{
		return (3.14*radius*radius);
	}
	
	public static void main(String[] args) 
	{
		Circle obj1 = new Circle();
		System.out.println(obj1.getRadius());
		System.out.println(obj1.getArea());
		Circle obj2 = new Circle(10.0);
		System.out.println(obj2.getRadius());
		System.out.println(obj2.getArea());
	}
}