
import java.lang.Math;
import java.util.*;
public class AreaOfTriangle
{
    double A(double a,double b,double c)
    {
        double s=(a+b+c)/2;
        double d=s*(s-a)*(s-b)*(s-c);
        double area=Math.sqrt(d);
        return area;
    }
	public static void main(String[] args) 
	{
	    AreaOfTriangle obj=new AreaOfTriangle();
	    System.out.println(obj.A(2,3,4));
	}
}
