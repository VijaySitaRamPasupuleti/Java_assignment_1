import java.util.Scanner;
public class Complex
{
	double real;
    	double imag;

    	public Complex(double real, double imag)
	{
        	this.real = real;
        	this.imag = imag;
    	}

    	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);

        	Double n1 = sc.nextDouble();
        	Double n2 = sc.nextDouble();
        	Double n3 = sc.nextDouble();
        	Double n4 = sc.nextDouble();

        	Complex obj1 = new Complex(n1, n2);
        	Complex obj2 = new Complex(n3, n4);
        	Complex temp_add,temp_sub,temp_mul;

        	temp_add = add(n1, n2);
        	temp_sub = subtract(n1, n2);
        	temp_mul = multiplication(n1, n2);
        
		if(temp_add.imag>=0)
        	{
            		System.out.printf("Sum = %.1f + %.1f i\n", temp_add.real, temp_add.imag);
        	}
        
		else
        	{
            		System.out.printf("Sum = %.1f %.1f i\n", temp_add.real, temp_add.imag);
        	}

        	if(temp_sub.imag>=0)
        	{
            		System.out.printf("difference = %.1f + %.1f i\n", temp_sub.real, temp_sub.imag);
        	}

        	else
        	{
            		System.out.printf("difference = %.1f %.1f i\n", temp_sub.real, temp_sub.imag);
        	}
         
		if(temp_mul.imag>=0)
        	{
            		System.out.printf("Product = %.1f + %.1f i\n", temp_mul.real, temp_mul.imag);
        	}

        	else
        	{
            		System.out.printf("Product = %.1f %.1f i\n", temp_mul.real, temp_mul.imag);
        	}
    }

    public static Complex add(Complex n1, Complex n2)
    {
        Complex temp = new Complex(0.0, 0.0);

        temp.real = n1.real + n2.real;
        temp.imag = n1.imag + n2.imag;

        return(temp);
    }
    public static Complex subtract(Complex n1,Complex n2)
    {
        Complex temp = new Complex(0.0,0.0);
        temp.real = n1.real - n2.real;
        temp.imag = n1.imag - n2.imag;
        return(temp);
    }
    public static Complex multiplication(Complex n1,Complex n2)
    {
        Complex temp = new Complex(0.0,0.0);
        temp.real = n1.real * n2.real - n1.imag * n2.imag;
        temp.imag = n1.real * n2.imag + n1.imag * n2.real;
        return(temp);
    }
}
