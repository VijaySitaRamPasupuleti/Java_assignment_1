import java.util.Scanner;
public class Main
{
    int id;
    String name;
    String designation;
    int salary;
    String city;
    Main(int id, String name,String designation,int salary, String city)
    {
        this.id=id;
        this.name=name;
        this.designation=designation;
        this.salary=salary;
        this.city=city;
    }
    public String toString()
    {
        return id+" "+name+" "+designation+" "+salary+" "+city;
    }
    public static void main(String args[])
    {
        Main[] obj=new Main[2];
        Scanner sc=new Scanner(System.in);
        int id;
        String name;
        String designation;
        int salary;
        String city;
        for(int i=0;i<2;i++)
        {
            id=sc.nextInt();
            name=sc.next();
            designation=sc.next();
            salary=sc.nextInt();
            city=sc.next();
            obj[i]=new Main(id,name,designation,salary,city);
        }
        System.out.println("----------------List of all employee's names----------------");
        for(int i=0;i<2;i++)
        {
        System.out.println("id"+i+"'s name "+obj[i].name);
        }
        System.out.println("----------------List of Salaries greater than 50000----------------");
        for(int i=0;i<2;i++)
        {
            if(obj[i].salary>50000)
            {
                System.out.println(obj[i].salary);
            }
        }
        System.out.println("----------------List of Locations starting with M----------------");
        for(int i=0;i<2;i++)
        {
            String location=obj[i].city;
            if(location.startsWith("M"))
            {
                System.out.println("id"+i+"'s location "+location);
            }
        }
        System.out.println("----------------List of designations ending with e----------------");
        for(int i=0;i<2;i++)
        {
            String d=obj[i].designation;
            if(d.endsWith("e"))
            {
                System.out.println("id"+i+"'s designation "+d);
            }
        }        
    }
}